<?
if($_GET['bo_table']== 'gallery') {
    $page_num = 1;
    $page_tit = '갤러리';
    $cate_num = 5;
    $cate_tit = '고객지원';
}

if($_GET['bo_table']== 'qa') {
    $page_num = 1;
    $page_tit = '문의게시판';
    $cate_num = 6;
    $cate_tit = '고객지원';
}
?>

<main id="content">
            <div id="subpage">
                <div class="top_page">
                    <div class="inner">
                        <span><?=$cate_tit;?></span> / <strong><?=$page_tit;?></strong>
                    </div>
                </div>
                <div class="content_wrap inner">
                    <article class="article">
                        <h2><strong><?=$page_tit;?></strong> / <span><?=$cate_tit;?></span> </h2>
                        <div class="content">